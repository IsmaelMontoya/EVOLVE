/* ============================================================
   PROJECT TEMPLATE - 04_semantic_views.sql
   Capa semantica
   ============================================================ */

/* QUE HACES EN ESTE ARCHIVO
   - Crear vistas faciles de leer y reutilizar
   - Preparar metricas para analisis posterior

   QUE TIENES QUE CAMBIAR
   - nombres de columnas
   - joins entre tablas core
   - metricas y agregaciones
   - funciones de fecha segun tu motor SQL

   NOTA
   - este ejemplo usa sintaxis compatible con MySQL
   - si usas SQLite/Postgres/DuckDB, adapta funciones como DATE_FORMAT
*/

USE student_project_sql;

CREATE OR REPLACE VIEW vw_events_enriched AS
SELECT
    f.fact_id,
    f.event_id,
    f.event_date,
    DATE_FORMAT(f.event_date, '%Y-%m-01') AS month_start,
    f.metric_value,
    de.entity_id,
    de.entity_name,
    de.region,
    dc.category_id,
    dc.category_name,
    dc.group_name
FROM fct_events f
JOIN dim_entities de ON de.entity_id = f.entity_id
JOIN dim_categories dc ON dc.category_id = f.category_id;

CREATE OR REPLACE VIEW vw_monthly_kpi AS
SELECT
    month_start,
    COUNT(*) AS n_events,
    SUM(metric_value) AS total_metric,
    AVG(metric_value) AS avg_metric
FROM vw_events_enriched
GROUP BY month_start;

CREATE OR REPLACE VIEW vw_region_monthly_kpi AS
SELECT
    t.month_start,
    t.region,
    t.n_events,
    t.total_metric,
    ROUND(100 * t.total_metric / NULLIF(SUM(t.total_metric) OVER (PARTITION BY t.month_start), 0), 2) AS month_share_pct
FROM (
    SELECT
        month_start,
        region,
        COUNT(*) AS n_events,
        SUM(metric_value) AS total_metric
    FROM vw_events_enriched
    GROUP BY month_start, region
) t;
