/* ============================================================
   PROJECT TEMPLATE - 08_advanced_sql.sql
   SQL avanzado
   Nota: este archivo esta orientado a MySQL.
   Si usas otro motor, adapta estas piezas a su equivalente.
   ============================================================ */

/* QUE HACES EN ESTE ARCHIVO
   - Incluir SQL mas avanzado
   - Demostrar que sabes ir mas alla del SELECT basico

   QUE TIENES QUE CAMBIAR
   - sintaxis segun el motor elegido
   - ejemplos placeholder por logica real de tu proyecto

   IMPORTANTE
   - si tu motor no soporta una pieza concreta, no pasa nada
   - sustituyela por una alternativa razonable y explicala en el README
*/

USE student_project_sql;

/* ---------- Function ---------- */
DELIMITER $$

DROP FUNCTION IF EXISTS fn_safe_pct$$
CREATE FUNCTION fn_safe_pct(p_num DECIMAL(14,4), p_den DECIMAL(14,4))
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    IF p_den IS NULL OR p_den = 0 THEN
        RETURN NULL;
    END IF;
    RETURN ROUND(100 * p_num / p_den, 2);
END$$

DELIMITER ;

/* ---------- Procedure ---------- */
DELIMITER $$

DROP PROCEDURE IF EXISTS sp_refresh_core$$
CREATE PROCEDURE sp_refresh_core(IN p_rebuild_views BOOLEAN)
BEGIN
    DECLARE v_fact_rows BIGINT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error en sp_refresh_core';
    END;

    START TRANSACTION;

    -- TODO: reemplaza por tu logica real
    -- ejemplo: TRUNCATE + INSERT a dim/fact desde staging
    SET v_fact_rows = (SELECT COUNT(*) FROM fct_events);

    COMMIT;

    IF p_rebuild_views THEN
        -- placeholder: aqui podrias refrescar snapshots si los tienes
        SELECT 'views/snapshots refresh simulated' AS info;
    END IF;

    SELECT v_fact_rows AS fact_rows_after_refresh;
END$$

DELIMITER ;

/* ---------- Trigger ---------- */
DELIMITER $$

DROP TRIGGER IF EXISTS trg_fct_events_bi_validate$$
CREATE TRIGGER trg_fct_events_bi_validate
BEFORE INSERT ON fct_events
FOR EACH ROW
BEGIN
    IF NEW.metric_value IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'metric_value no puede ser NULL';
    END IF;
END$$

DELIMITER ;

/* ---------- Smoke tests ---------- */
SELECT fn_safe_pct(25, 200) AS pct_example;
CALL sp_refresh_core(FALSE);
