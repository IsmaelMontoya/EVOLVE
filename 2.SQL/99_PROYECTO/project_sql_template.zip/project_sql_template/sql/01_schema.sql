/* ============================================================
   PROJECT TEMPLATE - 01_schema.sql
   Renombra tablas/campos segun tu dataset real
   ============================================================ */

/* QUE HACES EN ESTE ARCHIVO
   - Definir la estructura base del proyecto
   - Crear staging (`stg_*`) y core (`dim_*`, `fct_*`)
   - Adaptar nombres y tipos a tu dataset

   QUE TIENES QUE CAMBIAR
   - nombres de tablas
   - nombres de columnas
   - tipos de datos
   - claves primarias y foraneas

   IDEA CLAVE
   - staging = datos crudos
   - core = datos limpios y modelados
*/

CREATE DATABASE IF NOT EXISTS student_project_sql;
USE student_project_sql;

/* ---------- Staging (raw, todo texto) ---------- */
DROP TABLE IF EXISTS stg_events_raw;
DROP TABLE IF EXISTS stg_entities_raw;
DROP TABLE IF EXISTS stg_categories_raw;

CREATE TABLE stg_events_raw (
    raw_event_id VARCHAR(100),
    raw_entity_id VARCHAR(100),
    raw_category_id VARCHAR(100),
    raw_event_date VARCHAR(100),
    raw_metric_value VARCHAR(100),
    source_file VARCHAR(120),
    ingested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE stg_entities_raw (
    raw_entity_id VARCHAR(100),
    raw_entity_name VARCHAR(150),
    raw_region VARCHAR(100),
    source_file VARCHAR(120),
    ingested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE stg_categories_raw (
    raw_category_id VARCHAR(100),
    raw_category_name VARCHAR(150),
    raw_group_name VARCHAR(100),
    source_file VARCHAR(120),
    ingested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

/* ---------- Core (clean) ---------- */
DROP TABLE IF EXISTS fct_events;
DROP TABLE IF EXISTS dim_categories;
DROP TABLE IF EXISTS dim_entities;

CREATE TABLE dim_entities (
    entity_id INT PRIMARY KEY,
    entity_name VARCHAR(150) NOT NULL,
    region VARCHAR(100) NULL
);

CREATE TABLE dim_categories (
    category_id INT PRIMARY KEY,
    category_name VARCHAR(150) NOT NULL,
    group_name VARCHAR(100) NULL
);

CREATE TABLE fct_events (
    fact_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    event_id BIGINT NOT NULL,
    event_date DATE NOT NULL,
    entity_id INT NOT NULL,
    category_id INT NOT NULL,
    metric_value DECIMAL(14,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (entity_id) REFERENCES dim_entities(entity_id),
    FOREIGN KEY (category_id) REFERENCES dim_categories(category_id),
    INDEX idx_event_date (event_date),
    INDEX idx_entity (entity_id),
    INDEX idx_category (category_id)
);
