/* ============================================================
   PROJECT TEMPLATE - 03_transform_core.sql
   Limpieza + carga core desde staging
   ============================================================ */

/* QUE HACES EN ESTE ARCHIVO
   - Transformar datos crudos en tablas limpias
   - Cargar dimensiones
   - Cargar la fact principal

   QUE TIENES QUE CAMBIAR
   - reglas de limpieza
   - CAST y parseo de fechas
   - joins entre staging y dimensiones
   - filtros para excluir filas invalidas

   PREGUNTA QUE TE TIENES QUE HACER
   - cual es el grano de mi fact?
*/

USE student_project_sql;

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE fct_events;
TRUNCATE TABLE dim_entities;
TRUNCATE TABLE dim_categories;
SET FOREIGN_KEY_CHECKS = 1;

/* ---------- Dimensiones ---------- */
INSERT INTO dim_entities (entity_id, entity_name, region)
SELECT DISTINCT
    CAST(TRIM(raw_entity_id) AS UNSIGNED) AS entity_id,
    TRIM(raw_entity_name) AS entity_name,
    NULLIF(TRIM(raw_region), '') AS region
FROM stg_entities_raw
WHERE TRIM(raw_entity_id) REGEXP '^[0-9]+$';

INSERT INTO dim_categories (category_id, category_name, group_name)
SELECT DISTINCT
    CAST(TRIM(raw_category_id) AS UNSIGNED) AS category_id,
    TRIM(raw_category_name) AS category_name,
    NULLIF(TRIM(raw_group_name), '') AS group_name
FROM stg_categories_raw
WHERE TRIM(raw_category_id) REGEXP '^[0-9]+$';

/* ---------- Fact ---------- */
INSERT INTO fct_events (
    event_id,
    event_date,
    entity_id,
    category_id,
    metric_value
)
SELECT
    CAST(TRIM(e.raw_event_id) AS UNSIGNED) AS event_id,
    STR_TO_DATE(TRIM(e.raw_event_date), '%Y-%m-%d') AS event_date,
    CAST(TRIM(e.raw_entity_id) AS UNSIGNED) AS entity_id,
    CAST(TRIM(e.raw_category_id) AS UNSIGNED) AS category_id,
    CAST(TRIM(e.raw_metric_value) AS DECIMAL(14,2)) AS metric_value
FROM stg_events_raw e
JOIN dim_entities de
    ON de.entity_id = CAST(TRIM(e.raw_entity_id) AS UNSIGNED)
JOIN dim_categories dc
    ON dc.category_id = CAST(TRIM(e.raw_category_id) AS UNSIGNED)
WHERE TRIM(e.raw_event_id) REGEXP '^[0-9]+$'
  AND STR_TO_DATE(TRIM(e.raw_event_date), '%Y-%m-%d') IS NOT NULL
  AND TRIM(e.raw_metric_value) REGEXP '^-?[0-9]+(\\.[0-9]+)?$';

SELECT COUNT(*) AS n_facts FROM fct_events;
