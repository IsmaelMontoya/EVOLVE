/* ============================================================
   PROJECT TEMPLATE - 05_analysis_queries.sql
   Preguntas analiticas base (adaptar a tu caso)
   ============================================================ */

/* QUE HACES EN ESTE ARCHIVO
   - Responder preguntas de negocio con SQL
   - Mostrar que sabes analizar tablas ya modeladas

   QUE TIENES QUE CAMBIAR
   - las consultas
   - los comentarios
   - las metricas
   - el numero total de queries

   MINIMO ESPERADO
   - entre 8 y 12 consultas
   - que cada consulta tenga un objetivo claro
   - que no sean solo conteos triviales
*/

USE student_project_sql;

-- Q1: Evolucion mensual de la metrica total
SELECT *
FROM vw_monthly_kpi
ORDER BY month_start;

-- Q2: Top 5 entidades por metrica acumulada
SELECT
    entity_id,
    entity_name,
    SUM(metric_value) AS total_metric
FROM vw_events_enriched
GROUP BY entity_id, entity_name
ORDER BY total_metric DESC
LIMIT 5;

-- Q3: Top 3 por region (top-N por grupo)
WITH ranked AS (
    SELECT
        region,
        entity_id,
        entity_name,
        SUM(metric_value) AS total_metric,
        ROW_NUMBER() OVER (
            PARTITION BY region
            ORDER BY SUM(metric_value) DESC, entity_id
        ) AS rn
    FROM vw_events_enriched
    GROUP BY region, entity_id, entity_name
)
SELECT *
FROM ranked
WHERE rn <= 3
ORDER BY region, rn;

-- Q4: Ranking mensual por categoria
WITH category_month AS (
    SELECT
        month_start,
        category_name,
        SUM(metric_value) AS total_metric
    FROM vw_events_enriched
    GROUP BY month_start, category_name
)
SELECT
    cm.*,
    DENSE_RANK() OVER (
        PARTITION BY month_start
        ORDER BY total_metric DESC
    ) AS dense_rank_month
FROM category_month cm
ORDER BY month_start, dense_rank_month, category_name;
