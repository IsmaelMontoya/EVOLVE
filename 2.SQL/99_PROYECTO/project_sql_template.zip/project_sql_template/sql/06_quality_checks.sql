/* ============================================================
   PROJECT TEMPLATE - 06_quality_checks.sql
   Checklist de calidad de datos y modelo
   ============================================================ */

/* QUE HACES EN ESTE ARCHIVO
   - Comprobar que tus datos tienen sentido
   - Detectar errores antes de analizar

   QUE TIENES QUE CAMBIAR
   - reglas de nulos
   - checks de duplicados
   - validaciones de rango
   - checks especificos de tu negocio

   IDEA CLAVE
   - un buen proyecto no solo analiza: tambien valida
*/

USE student_project_sql;

-- 1) Nulos clave en core
SELECT
    SUM(CASE WHEN event_date IS NULL THEN 1 ELSE 0 END) AS null_event_date,
    SUM(CASE WHEN entity_id IS NULL THEN 1 ELSE 0 END) AS null_entity_id,
    SUM(CASE WHEN category_id IS NULL THEN 1 ELSE 0 END) AS null_category_id
FROM fct_events;

-- 2) Orfandad de claves foraneas (no deberia haber)
SELECT COUNT(*) AS orphan_entity
FROM fct_events f
LEFT JOIN dim_entities d ON d.entity_id = f.entity_id
WHERE d.entity_id IS NULL;

SELECT COUNT(*) AS orphan_category
FROM fct_events f
LEFT JOIN dim_categories c ON c.category_id = f.category_id
WHERE c.category_id IS NULL;

-- 3) Duplicados de negocio (ajusta la llave segun tu caso real)
SELECT
    event_id,
    event_date,
    entity_id,
    category_id,
    COUNT(*) AS n_dups
FROM fct_events
GROUP BY event_id, event_date, entity_id, category_id
HAVING COUNT(*) > 1
ORDER BY n_dups DESC;

-- 4) Rango de fechas
SELECT
    MIN(event_date) AS min_event_date,
    MAX(event_date) AS max_event_date
FROM fct_events;

-- 5) Metrica fuera de rango (ejemplo)
SELECT *
FROM fct_events
WHERE metric_value < 0;
