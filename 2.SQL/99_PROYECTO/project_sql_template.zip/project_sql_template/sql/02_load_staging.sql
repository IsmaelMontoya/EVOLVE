/* ============================================================
   PROJECT TEMPLATE - 02_load_staging.sql
   Importa CSV con DBeaver Wizard a tablas stg_* antes de ejecutar
   ============================================================ */

/* QUE HACES EN ESTE ARCHIVO
   - Validar que la carga a staging ha salido bien
   - Revisar volumen, muestras y problemas de parseo

   QUE TIENES QUE CAMBIAR
   - nombres de tablas staging
   - checks de ids
   - formato de fecha segun tu dataset
   - checks de metricas segun tus columnas reales

   CONSEJO
   - no sigas a core hasta que staging tenga sentido
*/

USE student_project_sql;

/* ---------- Checks de volumen ---------- */
SELECT 'stg_events_raw' AS table_name, COUNT(*) AS n_rows FROM stg_events_raw
UNION ALL
SELECT 'stg_entities_raw' AS table_name, COUNT(*) AS n_rows FROM stg_entities_raw
UNION ALL
SELECT 'stg_categories_raw' AS table_name, COUNT(*) AS n_rows FROM stg_categories_raw;

/* ---------- Muestras ---------- */
SELECT * FROM stg_events_raw LIMIT 10;
SELECT * FROM stg_entities_raw LIMIT 10;
SELECT * FROM stg_categories_raw LIMIT 10;

/* ---------- Checks de parseabilidad ---------- */
SELECT
    SUM(CASE WHEN raw_entity_id NOT REGEXP '^[0-9]+$' THEN 1 ELSE 0 END) AS bad_entity_id,
    SUM(CASE WHEN raw_category_id NOT REGEXP '^[0-9]+$' THEN 1 ELSE 0 END) AS bad_category_id,
    SUM(CASE WHEN STR_TO_DATE(raw_event_date, '%Y-%m-%d') IS NULL THEN 1 ELSE 0 END) AS bad_event_date,
    SUM(CASE WHEN raw_metric_value NOT REGEXP '^-?[0-9]+(\\.[0-9]+)?$' THEN 1 ELSE 0 END) AS bad_metric
FROM stg_events_raw;
