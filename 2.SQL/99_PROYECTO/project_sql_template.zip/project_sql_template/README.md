# SQL Project Template (engine-agnostic)

Esta carpeta es una plantilla para el proyecto final de SQL del master.
La plantilla esta inspirada en MySQL, pero se puede adaptar a SQLite, PostgreSQL, DuckDB u otro motor SQL.

La idea no es que lo copies tal cual.
La idea es que te sirva para organizar tu trabajo y para no mezclar carga, limpieza, modelado y analisis.

## Objetivo
Construir un mini pipeline reproducible:
- `stg_*` (raw)
- `dim_*` / `fct_*` (clean/core)
- `vw_*` (semantic)
- logica reutilizable (o el equivalente en el motor elegido)

## Orden recomendado de ejecucion
1. `sql/01_schema.sql`
2. Importar CSV a tablas `stg_*` con la herramienta que prefieras
3. `sql/02_load_staging.sql` (checks post-import)
4. `sql/03_transform_core.sql`
5. `sql/04_semantic_views.sql`
6. `sql/06_quality_checks.sql`
7. `sql/05_analysis_queries.sql`
8. `sql/07_advanced_sql.sql`

## Como usar esta plantilla
No tienes que copiarla tal cual.
Tu trabajo consiste en adaptarla a tu dataset.

Piensa en esta carpeta como un esqueleto:
- te da una estructura ordenada
- te recuerda las capas del proyecto
- te ayuda a no mezclar limpieza, modelado y analisis

## Que tienes que hacer en cada archivo

### `sql/01_schema.sql`
Aqui defines la estructura de tu proyecto.
Debes:
- cambiar nombres de tablas y columnas para que encajen con tu dataset
- decidir que tablas seran `stg_*`
- decidir que tablas seran `dim_*` y `fct_*`
- dejar claro el grano de la fact principal

### `sql/02_load_staging.sql`
Aqui validas que la carga inicial esta bien.
Debes:
- comprobar conteos
- inspeccionar muestras
- detectar ids mal formados, fechas invalidas o metricas sucias

### `sql/03_transform_core.sql`
Aqui conviertes datos raw en tablas limpias.
Debes:
- castear tipos
- limpiar texto
- cargar dimensiones
- cargar la tabla fact
- filtrar filas invalidas si hace falta

### `sql/04_semantic_views.sql`
Aqui creas la capa semantica.
Debes:
- construir al menos una vista enriquecida
- construir al menos 2 vistas utiles para analisis
- usar nombres comprensibles y metricas claras

### `sql/05_analysis_queries.sql`
Aqui respondes preguntas de negocio.
Debes:
- incluir entre 8 y 12 consultas
- comentar que responde cada una
- evitar queries descriptivas demasiado simples

### `sql/06_quality_checks.sql`
Aqui demuestras que validas tus datos.
Debes:
- revisar nulos
- revisar duplicados
- revisar orfandad de claves
- revisar rangos o valores anormalmente raros

### `sql/07_advanced_sql.sql`
Aqui incluyes SQL mas avanzado.
Debes:
- usar piezas compatibles con tu motor
- si el motor soporta `FUNCTION`, `PROCEDURE` o `TRIGGER`, puedes usarlas
- si no las soporta, sustituirlas por otra solucion y explicarlo en el README

## Que espero que se vea al corregir
- que entiendes tu dataset
- que has separado bien las capas
- que tus joins tienen sentido
- que tus preguntas de negocio son buenas
- que tu proyecto se puede reproducir

## Entregables minimos
1. Script SQL ejecutable de extremo a extremo.
2. Motor SQL elegido claramente indicado en el `README`.
3. Diagrama simple de modelo (`stg -> core -> views`).
4. 8-12 queries de analisis con respuesta de negocio.
5. Uso de SQL avanzado compatible con el motor elegido.
6. Si el motor soporta `FUNCTION`, `PROCEDURE` o `TRIGGER`, se valora su uso.
7. Si el motor no soporta alguna de esas piezas, debe incluirse una alternativa razonable y documentada.
8. README final con:
   - preguntas de negocio
   - supuestos
   - limites del dataset
   - checklist de calidad
   - instrucciones de reproduccion

## Criterios para elegir dataset
- Al menos 3 tablas con relacion real.
- Al menos una fecha usable.
- Al menos una metrica numerica.
- Potencial de joins no triviales.
- Suficiente "suciedad" para limpiar (nulos, formatos, duplicados).

## Sugerencia de repositorio del alumno
```text
project_name/
  data/               # csv originales o datos fuente
  sql/
    01_schema.sql
    02_load_staging.sql
    03_transform_core.sql
    04_semantic_views.sql
    05_analysis_queries.sql
    06_quality_checks.sql
    07_advanced_sql.sql
  PROJECT_BRIEF.md
  README.md
  project.db          # opcional si usan SQLite u otro archivo reproducible
```
